"""
Test script to verify model implementation
"""
import torch
import yaml
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from models.main_model import MultiModalModel
from data.dataset import create_synthetic_data


def test_model_components():
    """Test all model components"""
    print("=" * 50)
    print("Testing Multi-Modal Model Components")
    print("=" * 50)
    
    # Create config
    config = {
        'model': {
            'num_modalities': 3,
            'input_dims': [2048, 1024, 512],
            'latent_dim': 256,
            'num_clusters': 10,
            'temperature': 0.07,
            'alpha': 1.0
        },
        'loss': {
            'lambda_cl': 0.5,
            'lambda_grl': 1.0,
            'gamma_sch': 10.0,
            'gamma': 0.1,
            'lambda_geo': 1.0,
            'lambda_rest': 1.0
        }
    }
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Create model
    print("\n1. Creating model...")
    model = MultiModalModel(config).to(device)
    model.set_num_classes(10)
    print("   ✓ Model created successfully")
    
    # Create synthetic data
    print("\n2. Creating synthetic data...")
    data_dict, labels = create_synthetic_data(
        num_samples=100,
        num_modalities=3,
        input_dims=[2048, 1024, 512],
        num_classes=10
    )
    
    # Convert to tensors and move to device
    v_dict = {k: torch.FloatTensor(v[:32]).to(device) for k, v in data_dict.items()}
    labels_tensor = torch.LongTensor(labels[:32]).to(device)
    print(f"   ✓ Created data: {len(v_dict)} modalities, batch_size=32")
    
    # Test forward pass
    print("\n3. Testing forward pass...")
    try:
        outputs = model(v_dict, observed_modalities=list(v_dict.keys()))
        print(f"   ✓ Forward pass successful")
        print(f"     - z_dict keys: {list(outputs['z_dict'].keys())}")
        print(f"     - z_final_dict keys: {list(outputs['z_final_dict'].keys())}")
        print(f"     - h shape: {outputs['h'].shape}")
        print(f"     - logits shape: {outputs['logits'].shape if outputs['logits'] is not None else None}")
    except Exception as e:
        print(f"   ✗ Forward pass failed: {e}")
        return False
    
    # Test loss computation
    print("\n4. Testing loss computation...")
    try:
        losses = model.compute_losses(outputs, v_dict, labels_tensor, progress=0.5)
        print(f"   ✓ Loss computation successful")
        print(f"     - Total loss: {losses['total'].item():.4f}")
        print(f"     - Topo loss: {losses['topo'].item():.4f}")
        print(f"     - Recon loss: {losses['recon'].item():.4f}")
        print(f"     - Contrast loss: {losses['contrast'].item():.4f}")
        print(f"     - Rest loss: {losses['rest'].item():.4f}")
        print(f"     - Task loss: {losses['task'].item():.4f}")
    except Exception as e:
        print(f"   ✗ Loss computation failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # Test backward pass
    print("\n5. Testing backward pass...")
    try:
        losses['total'].backward()
        print(f"   ✓ Backward pass successful")
        
        # Check gradients
        has_grad = False
        for name, param in model.named_parameters():
            if param.grad is not None:
                has_grad = True
                break
        print(f"     - Gradients computed: {has_grad}")
    except Exception as e:
        print(f"   ✗ Backward pass failed: {e}")
        return False
    
    # Test with missing modalities
    print("\n6. Testing with missing modalities...")
    try:
        # Simulate missing one modality
        v_dict_partial = {k: v for k, v in list(v_dict.items())[:2]}
        observed = list(v_dict_partial.keys())
        outputs_partial = model(v_dict_partial, observed_modalities=observed)
        print(f"   ✓ Forward pass with missing modalities successful")
        print(f"     - Observed modalities: {observed}")
        print(f"     - Restored modalities: {list(outputs_partial['z_final_dict'].keys())}")
    except Exception as e:
        print(f"   ✗ Missing modality test failed: {e}")
        return False
    
    # Test geometric rectification
    print("\n7. Testing geometric rectification...")
    try:
        z_dict = outputs['z_dict']
        z_all = torch.cat([z_dict[m] for m in z_dict.keys()], dim=0)
        
        # Split into complete and incomplete (simulated)
        n_complete = z_all.size(0) // 2
        z_complete = z_all[:n_complete]
        z_incomplete = z_all[n_complete:]
        
        loss_align, loss_ad, loss_dec = model.geometric_rectification(
            z_complete, z_incomplete, progress=0.5
        )
        print(f"   ✓ Geometric rectification successful")
        print(f"     - Alignment loss: {loss_align.item():.4f}")
        print(f"     - Adversarial loss: {loss_ad.item():.4f}")
        print(f"     - KL divergence loss: {loss_dec.item():.4f}")
    except Exception as e:
        print(f"   ✗ Geometric rectification test failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    print("\n" + "=" * 50)
    print("All tests passed! ✓")
    print("=" * 50)
    return True


if __name__ == '__main__':
    success = test_model_components()
    sys.exit(0 if success else 1)

