# 实现细节配置

根据论文Implementation Details部分，已完成以下配置：

## 特征维度设置

- **Text (BERT-base)**: 768维
- **Visual (FACET)**: 35维  
- **Acoustic (COVAREP)**: 74维
- **共享空间**: 512维（L2归一化后位于单位超球面）

**配置位置**: `config.yaml` - `model.input_dims: [768, 35, 74]`, `model.latent_dim: 512`

## 训练配置

### Optimizer
- **类型**: Adam
- **β₁**: 0.9
- **β₂**: 0.999
- **初始学习率**: 1×10⁻³
- **最小学习率**: 1×10⁻⁶（cosine annealing）
- **学习率调度**: Cosine Annealing (1e-3 → 1e-6)

**配置位置**: `config.yaml` - `training` section, `train.py` - optimizer和scheduler设置

### 训练阶段
- **总轮数**: 100 epochs
- **Warm-up阶段**: 5 epochs（在启用几何校正和恢复之前）
- **Batch Size**: 
  - CMU-MOSI: 32
  - CMU-MOSEI: 64

**配置位置**: `config.yaml` - `training` section, `train.py` - warm-up逻辑

## 超参数设置

| 超参数 | 值 | 说明 | 配置位置 |
|--------|-----|------|---------|
| τ (temperature) | 0.1 | InfoNCE温度参数 | `config.yaml: model.temperature` |
| λ_cl | 0.3 | 对比拓扑权重 | `config.yaml: loss.lambda_cl` |
| γ | 0.1 | 对齐权衡参数 | `config.yaml: loss.gamma` |
| γ_sch | 10 | GRL调度斜率 | `config.yaml: loss.gamma_sch` |
| K | 20 | 原型数量 | `config.yaml: model.num_clusters` |
| α | 1.0 | Student-t参数 | `config.yaml: model.alpha` |
| m (EMA momentum) | 0.99 | 原型更新动量 | `config.yaml: model.ema_momentum` |
| 原型更新频率 | 5 | 每N次迭代更新一次 | `config.yaml: model.prototype_update_freq` |
| λ_geo | 0.4 | 几何校正权重 | `config.yaml: loss.lambda_geo` |
| λ_rest | 1.0 | 恢复损失权重 | `config.yaml: loss.lambda_rest` |

## 实现细节

### 1. Warm-up阶段
- 前5个epoch只训练拓扑一致性损失（L_topo）
- 不启用几何校正（L_align）和恢复损失（L_rest）
- 用于稳定初始训练

**实现位置**: `train.py:train_epoch()` - `is_warmup`判断

### 2. Cosine Annealing学习率调度
- 从1e-3线性衰减到1e-6
- 每个batch更新一次学习率
- 平滑的学习率衰减

**实现位置**: `train.py` - `CosineAnnealingLR` scheduler

### 3. EMA原型更新
- 使用指数移动平均（EMA）更新聚类原型
- 动量参数m=0.99
- 每5次迭代更新一次，减少计算开销

**实现位置**: `models/geometric_rectification.py` - `update_prototypes()`和更新频率控制

### 4. 数据集特定配置
- 根据数据集自动调整batch size
- CMU-MOSI: batch_size=32
- CMU-MOSEI: batch_size=64

**实现位置**: `train.py:main()` - 数据集判断

## 代码修改总结

### 更新的文件

1. **config.yaml**
   - 更新输入维度为[768, 35, 74]
   - 更新latent_dim为512
   - 更新所有超参数为论文值
   - 添加warm-up、EMA momentum等配置

2. **models/geometric_rectification.py**
   - 添加EMA momentum参数
   - 添加原型更新频率控制
   - 实现每N次迭代更新原型

3. **models/main_model.py**
   - 传递EMA momentum和更新频率参数

4. **train.py**
   - 实现warm-up阶段（前5个epoch）
   - 实现cosine annealing学习率调度
   - 使用正确的Adam参数（β1=0.9, β2=0.999）
   - 根据数据集调整batch size
   - 在warm-up阶段禁用几何校正和恢复损失

## 使用说明

1. **配置文件**: 所有超参数已在`config.yaml`中设置
2. **训练**: 运行`python train.py`，会自动：
   - 前5个epoch进行warm-up（只训练拓扑一致性）
   - 之后启用完整的损失（包括几何校正和恢复）
   - 使用cosine annealing调度学习率
   - 每5次迭代更新一次原型

3. **验证**: 运行`python test_model.py`测试模型组件

## 实验设置

- **重复次数**: 5次（不同随机种子）
- **报告结果**: 平均结果
- **硬件**: NVIDIA RTX 4090 GPU (24GB)
- **框架**: PyTorch

所有实现细节已按照论文要求完成配置！

