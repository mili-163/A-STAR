"""
Training utilities
"""
import torch
import torch.nn as nn


def compute_discriminator_loss(domain_discriminator, z_complete, z_incomplete, grl):
    """
    Compute discriminator loss (without GRL, for training discriminator)
    Args:
        domain_discriminator: domain discriminator
        z_complete: embeddings from complete samples
        z_incomplete: embeddings from incomplete samples
        grl: gradient reversal layer
    Returns:
        loss: discriminator loss
    """
    # For complete samples: label=1, maximize log D(z)
    d_complete = domain_discriminator(z_complete)
    loss_complete = -torch.mean(torch.log(d_complete + 1e-8))
    
    # For incomplete samples: label=0, maximize log(1 - D(z))
    d_incomplete = domain_discriminator(z_incomplete)
    loss_incomplete = -torch.mean(torch.log(1 - d_incomplete + 1e-8))
    
    loss = loss_complete + loss_incomplete
    return loss


def separate_batch_by_completeness(batch_dict, num_modalities):
    """
    Separate batch into complete and incomplete samples
    Args:
        batch_dict: batch dictionary with 'observed' field
        num_modalities: total number of modalities
    Returns:
        complete_indices: indices of complete samples
        incomplete_indices: indices of incomplete samples
    """
    complete_indices = []
    incomplete_indices = []
    
    for i, observed in enumerate(batch_dict['observed']):
        if len(observed) == num_modalities:
            complete_indices.append(i)
        else:
            incomplete_indices.append(i)
    
    return complete_indices, incomplete_indices


def extract_embeddings_by_indices(z_dict, indices):
    """
    Extract embeddings for specific indices from z_dict
    Args:
        z_dict: dict of {modality_id: embeddings} [batch_size, latent_dim]
        indices: list of indices to extract
    Returns:
        z_extracted: concatenated embeddings [len(indices)*num_modalities, latent_dim]
    """
    if len(indices) == 0:
        return None
    
    z_list = []
    for m in sorted(z_dict.keys()):
        z_m = z_dict[m][indices]
        z_list.append(z_m)
    
    if len(z_list) > 0:
        return torch.cat(z_list, dim=0)
    return None

