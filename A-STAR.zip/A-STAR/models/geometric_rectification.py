"""
Geometric Rectification via Soft-Cluster Evolution
- Global alignment via adversarial training
- Semantic anchoring via soft-cluster evolution
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class GradientReversalLayer(torch.autograd.Function):
    """
    Gradient Reversal Layer (GRL)
    R(x) = x with dR/dx = -lambda_grl * I
    """
    @staticmethod
    def forward(ctx, x, lambda_grl):
        ctx.lambda_grl = lambda_grl
        return x.view_as(x)
    
    @staticmethod
    def backward(ctx, grad_output):
        return -ctx.lambda_grl * grad_output, None


class GradientReversal(nn.Module):
    """Wrapper for GRL"""
    def __init__(self, lambda_grl=1.0):
        super(GradientReversal, self).__init__()
        self.lambda_grl = lambda_grl
    
    def forward(self, x):
        return GradientReversalLayer.apply(x, self.lambda_grl)


class DomainDiscriminator(nn.Module):
    """
    Domain discriminator D_ad to distinguish X_C and X_I
    """
    def __init__(self, latent_dim, hidden_dims=None):
        super(DomainDiscriminator, self).__init__()
        if hidden_dims is None:
            hidden_dims = [128, 64]
        
        layers = []
        prev_dim = latent_dim
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(0.1))
            prev_dim = hidden_dim
        
        layers.append(nn.Linear(prev_dim, 1))
        layers.append(nn.Sigmoid())
        self.discriminator = nn.Sequential(*layers)
    
    def forward(self, z):
        return self.discriminator(z)


class SoftClusterEvolution(nn.Module):
    """
    Soft-cluster evolution module with Student-t assignment
    Equations (5-7): soft assignment and KL divergence
    """
    def __init__(self, latent_dim, num_clusters, alpha=1.0):
        super(SoftClusterEvolution, self).__init__()
        self.latent_dim = latent_dim
        self.num_clusters = num_clusters
        self.alpha = alpha
        
        # Initialize cluster prototypes
        self.register_buffer('prototypes', None)
    
    def initialize_prototypes(self, z_complete):
        """
        Initialize K cluster prototypes using complete samples
        Args:
            z_complete: embeddings from complete samples [N_C, latent_dim]
        """
        # Ensure input is normalized
        z_complete = z_complete / (torch.norm(z_complete, p=2, dim=1, keepdim=True) + 1e-8)
        
        # Use k-means initialization or random selection
        device = z_complete.device
        N_C = z_complete.size(0)
        if N_C >= self.num_clusters:
            indices = torch.randperm(N_C, device=device)[:self.num_clusters]
            self.prototypes = z_complete[indices].clone()
        else:
            # If not enough samples, use random initialization on hypersphere
            device = z_complete.device
            self.prototypes = torch.randn(self.num_clusters, self.latent_dim, device=device)
            self.prototypes = self.prototypes / (torch.norm(self.prototypes, p=2, dim=1, keepdim=True) + 1e-8)
        
        # Ensure prototypes are normalized
        self.prototypes = self.prototypes / (torch.norm(self.prototypes, p=2, dim=1, keepdim=True) + 1e-8)
    
    def compute_soft_assignment(self, z):
        """
        Compute soft assignment q_{ik} using Student-t distribution
        Equation (5): q_{ik} = (1 + ||z_i - mu_k||^2/alpha)^{-(alpha+1)/2} / sum_j(...)
        Args:
            z: embeddings [batch_size, latent_dim]
        Returns:
            q: soft assignments [batch_size, num_clusters]
        """
        if self.prototypes is None:
            raise ValueError("Prototypes not initialized. Call initialize_prototypes first.")
        
        # Compute distances: [batch_size, num_clusters]
        distances = torch.cdist(z, self.prototypes, p=2) ** 2  # [B, K]
        
        # Student-t kernel: (1 + d/alpha)^{-(alpha+1)/2}
        numerator = torch.pow(1 + distances / self.alpha, -(self.alpha + 1) / 2)
        
        # Normalize
        denominator = torch.sum(numerator, dim=1, keepdim=True)  # [B, 1]
        q = numerator / (denominator + 1e-8)  # [B, K]
        
        return q
    
    def compute_target_distribution(self, q):
        """
        Build target distribution p_{ik} = q_{ik}^2 / f_k / sum_j(q_{ij}^2 / f_j)
        where f_k = sum_i q_{ik}
        Args:
            q: soft assignments [batch_size, num_clusters]
        Returns:
            p: target distribution [batch_size, num_clusters]
        """
        # f_k = sum_i q_{ik}
        f_k = torch.sum(q, dim=0, keepdim=True)  # [1, K]
        
        # q^2 / f_k
        q_squared = q ** 2
        numerator = q_squared / (f_k + 1e-8)  # [B, K]
        
        # Normalize
        denominator = torch.sum(numerator, dim=1, keepdim=True)  # [B, 1]
        p = numerator / (denominator + 1e-8)  # [B, K]
        
        return p
    
    def update_prototypes(self, z, q, momentum=0.9):
        """
        Update cluster prototypes using soft assignments
        Args:
            z: embeddings [batch_size, latent_dim]
            q: soft assignments [batch_size, num_clusters]
            momentum: momentum for prototype update
        """
        # Weighted average: mu_k = sum_i(q_{ik} * z_i) / sum_i(q_{ik})
        q_sum = torch.sum(q, dim=0, keepdim=True)  # [1, K]
        weighted_sum = torch.matmul(q.t(), z)  # [K, latent_dim]
        new_prototypes = weighted_sum / (q_sum.t() + 1e-8)  # [K, latent_dim]
        
        # Normalize new prototypes to keep them on the hypersphere
        new_prototypes = new_prototypes / (torch.norm(new_prototypes, p=2, dim=1, keepdim=True) + 1e-8)
        
        # Momentum update
        if self.prototypes is not None:
            self.prototypes = momentum * self.prototypes + (1 - momentum) * new_prototypes
        else:
            self.prototypes = new_prototypes
        
        # Ensure prototypes remain normalized after update
        self.prototypes = self.prototypes / (torch.norm(self.prototypes, p=2, dim=1, keepdim=True) + 1e-8)


class GeometricRectification(nn.Module):
    """
    Geometric Rectification Module
    Combines adversarial alignment and soft-cluster evolution
    Equation (8): L_align = L_dec + gamma * L_ad
    """
    def __init__(self, latent_dim, num_clusters, alpha=1.0, gamma=0.1, 
                 lambda_grl_init=1.0, gamma_sch=10.0, ema_momentum=0.99,
                 prototype_update_freq=5):
        super(GeometricRectification, self).__init__()
        self.latent_dim = latent_dim
        self.gamma = gamma
        self.lambda_grl_init = lambda_grl_init
        self.gamma_sch = gamma_sch
        self.ema_momentum = ema_momentum
        self.prototype_update_freq = prototype_update_freq
        self.update_counter = 0  # Counter for prototype update frequency
        
        self.domain_discriminator = DomainDiscriminator(latent_dim)
        self.grl = GradientReversal(lambda_grl_init)
        self.soft_cluster = SoftClusterEvolution(latent_dim, num_clusters, alpha)
    
    def compute_grl_weight(self, progress):
        """
        Compute scheduled GRL weight
        lambda_grl = 2 / (1 + exp(-gamma_sch * p)) - 1
        Args:
            progress: training progress p in [0, 1] (float or tensor)
        Returns:
            lambda_grl: scheduled weight (float)
        """
        # Convert to tensor if needed, ensure it's on the correct device
        # Get device from domain discriminator parameters
        device = next(self.domain_discriminator.parameters()).device
        if not isinstance(progress, torch.Tensor):
            progress_tensor = torch.tensor(progress, dtype=torch.float32, device=device)
        else:
            progress_tensor = progress.to(device) if progress.device != device else progress
        
        lambda_grl = 2.0 / (1.0 + torch.exp(-self.gamma_sch * progress_tensor)) - 1.0
        
        # Convert back to float if input was float
        if not isinstance(progress, torch.Tensor):
            return lambda_grl.item()
        return lambda_grl
    
    def forward(self, z_complete, z_incomplete, progress=0.0, update_prototypes=True):
        """
        Args:
            z_complete: embeddings from complete samples [N_C, latent_dim]
            z_incomplete: embeddings from incomplete samples [N_I, latent_dim]
            progress: training progress [0, 1]
            update_prototypes: whether to update cluster prototypes
        Returns:
            loss_align: total alignment loss
            loss_ad: adversarial loss
            loss_dec: KL divergence loss
        """
        # Update GRL weight based on progress
        lambda_grl = self.compute_grl_weight(progress)
        self.grl.lambda_grl = lambda_grl
        
        # Initialize prototypes if needed
        if self.soft_cluster.prototypes is None:
            self.soft_cluster.initialize_prototypes(z_complete)
        
        # Adversarial loss (Equation 6)
        # L_ad = -E_{x~X_C}[log D_ad(R(z_i))] - E_{x~X_I}[log(1 - D_ad(R(z_i)))]
        # For complete samples: maximize log D_ad(R(z_i)) (label=1)
        z_complete_rev = self.grl(z_complete)
        d_complete = self.domain_discriminator(z_complete_rev)
        loss_ad_complete = -torch.mean(torch.log(d_complete + 1e-8))
        
        # For incomplete samples: maximize log(1 - D_ad(R(z_i))) (label=0)
        z_incomplete_rev = self.grl(z_incomplete)
        d_incomplete = self.domain_discriminator(z_incomplete_rev)
        loss_ad_incomplete = -torch.mean(torch.log(1 - d_incomplete + 1e-8))
        
        # Total adversarial loss (for encoder, via GRL)
        loss_ad = loss_ad_complete + loss_ad_incomplete
        
        # Soft-cluster evolution loss (Equation 7)
        # Compute soft assignments for incomplete samples
        q = self.soft_cluster.compute_soft_assignment(z_incomplete)  # [N_I, K]
        p = self.soft_cluster.compute_target_distribution(q)  # [N_I, K]
        
        # KL divergence: KL(P||Q) = sum_i sum_k p_{ik} * log(p_{ik} / q_{ik})
        # Use mean over samples for numerical stability
        kl_per_sample = torch.sum(p * torch.log((p / (q + 1e-8)) + 1e-8), dim=1)  # [N_I]
        loss_dec = torch.mean(kl_per_sample)
        
        # Update prototypes with EMA momentum and frequency control
        if update_prototypes and self.training:
            self.update_counter += 1
            # Update prototypes every N iterations (prototype_update_freq)
            if self.update_counter % self.prototype_update_freq == 0:
                self.soft_cluster.update_prototypes(
                    z_incomplete, q, momentum=self.ema_momentum
                )
        
        # Total alignment loss (Equation 8)
        loss_align = loss_dec + self.gamma * loss_ad
        
        return loss_align, loss_ad, loss_dec
    
    def compute_discriminator_loss(self, z_complete, z_incomplete):
        """
        Compute discriminator loss for training the domain discriminator
        (without GRL, for separate discriminator training)
        Args:
            z_complete: embeddings from complete samples [N_C, latent_dim]
            z_incomplete: embeddings from incomplete samples [N_I, latent_dim]
        Returns:
            loss_disc: discriminator loss
        """
        # For complete samples: label=1, maximize log D(z)
        d_complete = self.domain_discriminator(z_complete)
        loss_complete = -torch.mean(torch.log(d_complete + 1e-8))
        
        # For incomplete samples: label=0, maximize log(1 - D(z))
        d_incomplete = self.domain_discriminator(z_incomplete)
        loss_incomplete = -torch.mean(torch.log(1 - d_incomplete + 1e-8))
        
        loss_disc = loss_complete + loss_incomplete
        return loss_disc
    
    def get_prototypes(self):
        """Get current cluster prototypes"""
        return self.soft_cluster.prototypes

