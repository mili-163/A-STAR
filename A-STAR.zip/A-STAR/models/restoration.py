"""
Adaptive Dual-Stream Structural Restoration
- Stream I: Residual cross-modal mapping
- Stream II: Prototype induction via external memory
- Adaptive fusion
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class ResidualMapper(nn.Module):
    """
    Stream I: Residual cross-modal mapping
    h_map^{u->v} = z^(u) + f_{u->v}(LN(z^(u)))
    """
    def __init__(self, latent_dim, hidden_dims=None):
        super(ResidualMapper, self).__init__()
        if hidden_dims is None:
            hidden_dims = [128]
        
        layers = []
        prev_dim = latent_dim
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.ReLU())
            prev_dim = hidden_dim
        
        layers.append(nn.Linear(prev_dim, latent_dim))
        self.mapper = nn.Sequential(*layers)
        self.layer_norm = nn.LayerNorm(latent_dim)
    
    def forward(self, z_u):
        """
        Args:
            z_u: aligned latent of modality u [batch_size, latent_dim]
        Returns:
            h_map: mapped feature [batch_size, latent_dim]
        """
        z_norm = self.layer_norm(z_u)
        residual = self.mapper(z_norm)
        h_map = z_u + residual
        return h_map


class PrototypeInduction(nn.Module):
    """
    Stream II: Prototype induction via external memory
    Uses attention mechanism to retrieve prototype features
    """
    def __init__(self, latent_dim, num_clusters):
        super(PrototypeInduction, self).__init__()
        self.latent_dim = latent_dim
        self.num_clusters = num_clusters
    
    def forward(self, z_u, prototypes, W_q):
        """
        Args:
            z_u: aligned latent of modality u [batch_size, latent_dim]
            prototypes: cluster prototypes [num_clusters, latent_dim]
            W_q: query projection matrix for target modality [latent_dim, latent_dim]
        Returns:
            h_proto: prototype-induced feature [batch_size, latent_dim]
        """
        # Compute attention weights
        # beta_k^{u->v} = exp(z_u^T * W_q * mu_k) / sum_j exp(z_u^T * W_q * mu_j)
        z_proj = torch.matmul(z_u, W_q)  # [batch_size, latent_dim]
        scores = torch.matmul(z_proj, prototypes.t())  # [batch_size, num_clusters]
        beta = F.softmax(scores, dim=1)  # [batch_size, num_clusters]
        
        # Weighted sum of prototypes
        h_proto = torch.matmul(beta, prototypes)  # [batch_size, latent_dim]
        
        return h_proto


class AdaptiveFusion(nn.Module):
    """
    Adaptive fusion of two streams via gate mechanism
    """
    def __init__(self, latent_dim):
        super(AdaptiveFusion, self).__init__()
        self.gate = nn.Sequential(
            nn.Linear(2 * latent_dim, latent_dim),
            nn.ReLU(),
            nn.Linear(latent_dim, latent_dim),
            nn.Sigmoid()
        )
    
    def forward(self, h_map, h_proto):
        """
        Args:
            h_map: instance-driven feature [batch_size, latent_dim]
            h_proto: prototype-driven feature [batch_size, latent_dim]
        Returns:
            z_fused: fused feature [batch_size, latent_dim]
            gate: gate values [batch_size, latent_dim]
        """
        # Concatenate features
        h_concat = torch.cat([h_map, h_proto], dim=1)  # [batch_size, 2*latent_dim]
        
        # Compute gate
        gate = self.gate(h_concat)  # [batch_size, latent_dim]
        
        # Fused output
        z_fused = gate * h_map + (1 - gate) * h_proto
        
        return z_fused, gate


class ModalityRestoration(nn.Module):
    """
    Complete restoration module for a specific modality pair
    """
    def __init__(self, latent_dim, num_clusters, target_modality_id=None):
        super(ModalityRestoration, self).__init__()
        self.latent_dim = latent_dim
        self.residual_mapper = ResidualMapper(latent_dim)
        self.prototype_induction = PrototypeInduction(latent_dim, num_clusters)
        self.adaptive_fusion = AdaptiveFusion(latent_dim)
        
        # Query projection for target modality
        # W_q^(v) as per equation
        self.query_projection = nn.Linear(
            latent_dim, latent_dim, bias=False
        )
    
    def forward(self, z_u, prototypes):
        """
        Restore target modality from source modality u
        Args:
            z_u: aligned latent of source modality u [batch_size, latent_dim]
            prototypes: cluster prototypes [num_clusters, latent_dim]
        Returns:
            z_restored: restored latent [batch_size, latent_dim]
        """
        # Stream I: Residual mapping
        # h_map^{u->v} = z^(u) + f_{u->v}(LN(z^(u)))
        h_map = self.residual_mapper(z_u)
        
        # Stream II: Prototype induction
        # beta_k^{u->v} = exp(z_u^T * W_q^(v) * mu_k) / sum_j exp(z_u^T * W_q^(v) * mu_j)
        # h_proto^{u->v} = sum_k beta_k^{u->v} * mu_k
        W_q = self.query_projection.weight  # [latent_dim, latent_dim]
        h_proto = self.prototype_induction(z_u, prototypes, W_q)
        
        # Adaptive fusion
        # g^{u->v} = sigma(W_g^(v) * [h_map || h_proto] + b_g^(v))
        # z^(u->v) = g^{u->v} * h_map + (1 - g^{u->v}) * h_proto
        z_restored, gate = self.adaptive_fusion(h_map, h_proto)
        
        return z_restored


class StructuralRestoration(nn.Module):
    """
    Complete structural restoration module
    Handles multiple observed modalities and aggregates predictions
    """
    def __init__(self, num_modalities, latent_dim, num_clusters):
        super(StructuralRestoration, self).__init__()
        self.num_modalities = num_modalities
        self.latent_dim = latent_dim
        
        # Create restoration modules for each modality pair (u->v)
        # Each target modality v has its own set of restoration modules
        self.restorations = nn.ModuleDict()
        for u in range(num_modalities):
            for v in range(num_modalities):
                if u != v:
                    key = f"{u}->{v}"
                    # Each restoration module is specific to a target modality v
                    self.restorations[key] = ModalityRestoration(latent_dim, num_clusters)
    
    def forward(self, z_dict, observed_modalities, target_modality, prototypes):
        """
        Restore target modality using observed modalities
        Args:
            z_dict: dict of {modality_id: z_embeddings} [batch_size, latent_dim]
            observed_modalities: list of observed modality IDs
            target_modality: target modality ID to restore
            prototypes: cluster prototypes [num_clusters, latent_dim]
        Returns:
            z_final: final restored/refined latent [batch_size, latent_dim]
        """
        predictions = []
        
        # Determine batch size (use the maximum batch size across all observed modalities)
        batch_sizes = [z_dict[u].size(0) for u in observed_modalities if u in z_dict]
        if len(batch_sizes) > 0:
            max_batch_size = max(batch_sizes)
            device = list(z_dict.values())[0].device
        else:
            max_batch_size = 0
            device = list(z_dict.values())[0].device if len(z_dict) > 0 else torch.device('cpu')
        
        # For each observed modality, predict target modality
        for u in observed_modalities:
            if u not in z_dict:
                continue
                
            if u == target_modality:
                # If target is observed, we can still refine it using other modalities
                # But for simplicity, we use it directly here
                z_u = z_dict[u]
                # Ensure same batch size
                if z_u.size(0) < max_batch_size:
                    padding = torch.zeros(max_batch_size - z_u.size(0), self.latent_dim, device=device)
                    z_u = torch.cat([z_u, padding], dim=0)
                elif z_u.size(0) > max_batch_size:
                    z_u = z_u[:max_batch_size]
                predictions.append(z_u)
            else:
                # Restore from source modality u to target modality v
                key = f"{u}->{target_modality}"
                if key in self.restorations:
                    z_u = z_dict[u]
                    z_restored = self.restorations[key](z_u, prototypes)
                    # Ensure same batch size
                    if z_restored.size(0) < max_batch_size:
                        padding = torch.zeros(max_batch_size - z_restored.size(0), self.latent_dim, device=device)
                        z_restored = torch.cat([z_restored, padding], dim=0)
                    elif z_restored.size(0) > max_batch_size:
                        z_restored = z_restored[:max_batch_size]
                    predictions.append(z_restored)
                else:
                    # Fallback: use source modality directly if restoration module not found
                    z_u = z_dict[u]
                    if z_u.size(0) < max_batch_size:
                        padding = torch.zeros(max_batch_size - z_u.size(0), self.latent_dim, device=device)
                        z_u = torch.cat([z_u, padding], dim=0)
                    elif z_u.size(0) > max_batch_size:
                        z_u = z_u[:max_batch_size]
                    predictions.append(z_u)
        
        # Aggregate predictions via mean
        # z_final^(v) = (1/|O|) * sum_{u in O} z^(u->v)
        if len(predictions) > 0:
            z_final = torch.stack(predictions, dim=0).mean(dim=0)
            # Ensure output is on the hypersphere (L2 normalized)
            z_final = z_final / (torch.norm(z_final, p=2, dim=1, keepdim=True) + 1e-8)
        else:
            # Fallback: use zero vector if no predictions
            z_final = torch.zeros(max_batch_size, self.latent_dim, device=device)
        
        return z_final
    
    def compute_restoration_loss(self, z_dict_complete, prototypes, mask_prob=0.3):
        """
        Self-supervised restoration loss on complete samples
        Equation (9): L_rest = E_x~X_C E_v~M(x) [||z^(v) - z_final^(v)||_2^2]
        For each complete sample, randomly mask one modality and restore it
        Args:
            z_dict_complete: dict of {modality_id: z_embeddings} for complete samples
            prototypes: cluster prototypes [num_clusters, latent_dim]
            mask_prob: probability of masking a modality during training (not used, we always mask one)
        Returns:
            loss: restoration loss (average MSE over all masked modalities)
        """
        batch_size = list(z_dict_complete.values())[0].size(0)
        device = list(z_dict_complete.values())[0].device
        
        if batch_size == 0:
            return torch.tensor(0.0, device=device)
        
        available_modalities = sorted(list(z_dict_complete.keys()))
        num_modalities = len(available_modalities)
        
        if num_modalities < 2:
            # Need at least 2 modalities for restoration
            return torch.tensor(0.0, device=device)
        
        total_loss = 0.0
        num_pairs = 0
        
        # For each sample, randomly mask one modality and restore it
        for i in range(batch_size):
            # Randomly select one modality to mask
            target_modality_idx = torch.randint(0, num_modalities, (1,)).item()
            target_modality = available_modalities[target_modality_idx]
            observed_modalities = [m for m in available_modalities if m != target_modality]
            
            # Get embeddings for this sample - clone to avoid computation graph issues
            z_sample = {m: z_dict_complete[m][i:i+1].clone() for m in available_modalities}
            
            # Restore target modality using observed modalities
            try:
                z_restored = self.forward(z_sample, observed_modalities, 
                                        target_modality, prototypes)
                
                # Ground truth - clone to avoid computation graph issues
                z_gt = z_dict_complete[target_modality][i:i+1].clone()
                
                # Ensure same batch size
                if z_restored.size(0) != z_gt.size(0):
                    min_size = min(z_restored.size(0), z_gt.size(0))
                    z_restored = z_restored[:min_size]
                    z_gt = z_gt[:min_size]
                
                # Compute MSE loss: ||z^(v) - z_final^(v)||_2^2
                if z_restored.size(0) > 0:
                    loss = F.mse_loss(z_restored, z_gt)
                    total_loss += loss
                    num_pairs += 1
            except Exception as e:
                continue
        
        if num_pairs > 0:
            return total_loss / num_pairs
        else:
            return torch.tensor(0.0, device=device)

