"""
Main model integrating all components
"""
import torch
import torch.nn as nn
from .encoders import ModalityEncoder, ModalityDecoder, HypersphericalProjection
from .topology import TopologyConsistencyLoss
from .geometric_rectification import GeometricRectification
from .restoration import StructuralRestoration
from .fusion import ModalityFusion, Classifier


class MultiModalModel(nn.Module):
    """
    Complete multi-modal model with non-IID missing modality handling
    """
    def __init__(self, config):
        super(MultiModalModel, self).__init__()
        self.config = config
        
        # Model parameters
        self.num_modalities = config['model']['num_modalities']
        self.input_dims = config['model']['input_dims']
        self.latent_dim = config['model']['latent_dim']
        self.num_clusters = config['model']['num_clusters']
        self.temperature = config['model']['temperature']
        self.alpha = config['model']['alpha']
        
        # Loss weights
        self.lambda_cl = config['loss']['lambda_cl']
        self.gamma = config['loss']['gamma']
        self.lambda_geo = config['loss']['lambda_geo']
        self.lambda_rest = config['loss']['lambda_rest']
        
        # Build encoders and decoders for each modality
        self.encoders = nn.ModuleDict()
        self.decoders = nn.ModuleDict()
        self.hypersphere_projections = nn.ModuleDict()
        
        for m in range(self.num_modalities):
            encoder = ModalityEncoder(self.input_dims[m], self.latent_dim)
            decoder = ModalityDecoder(self.latent_dim, self.input_dims[m])
            projection = HypersphericalProjection(encoder)
            
            self.encoders[str(m)] = encoder
            self.decoders[str(m)] = decoder
            self.hypersphere_projections[str(m)] = projection
        
        # Topology consistency loss
        self.topology_loss_fn = TopologyConsistencyLoss(
            lambda_cl=self.lambda_cl,
            temperature=self.temperature
        )
        
        # Geometric rectification
        ema_momentum = config['model'].get('ema_momentum', 0.99)
        prototype_update_freq = config['model'].get('prototype_update_freq', 5)
        self.geometric_rectification = GeometricRectification(
            latent_dim=self.latent_dim,
            num_clusters=self.num_clusters,
            alpha=self.alpha,
            gamma=self.gamma,
            lambda_grl_init=config['loss']['lambda_grl'],
            gamma_sch=config['loss']['gamma_sch'],
            ema_momentum=ema_momentum,
            prototype_update_freq=prototype_update_freq
        )
        
        # Structural restoration
        self.structural_restoration = StructuralRestoration(
            num_modalities=self.num_modalities,
            latent_dim=self.latent_dim,
            num_clusters=self.num_clusters
        )
        
        # Fusion and classification
        self.fusion = ModalityFusion(
            num_modalities=self.num_modalities,
            latent_dim=self.latent_dim,
            fusion_type='attention'
        )
        
        # Note: num_classes should be provided during initialization or training
        self.classifier = None
    
    def set_num_classes(self, num_classes):
        """Set number of classes for classification"""
        device = next(self.parameters()).device
        self.classifier = Classifier(
            latent_dim=self.latent_dim,
            num_classes=num_classes
        ).to(device)
    
    def encode_modalities(self, v_dict):
        """
        Encode all modalities to hyperspherical space
        Args:
            v_dict: dict of {modality_id: features} [batch_size, input_dim]
        Returns:
            z_dict: dict of {modality_id: normalized_embeddings} [batch_size, latent_dim]
        """
        z_dict = {}
        for m, v_m in v_dict.items():
            z_m = self.hypersphere_projections[m](v_m)
            z_dict[m] = z_m
        return z_dict
    
    def forward(self, v_dict, observed_modalities=None, training_phase='all'):
        """
        Forward pass
        Args:
            v_dict: dict of {modality_id: features}
            observed_modalities: list of observed modality IDs (None means all observed)
            training_phase: 'topology', 'alignment', 'restoration', 'all'
        Returns:
            outputs: dict containing various outputs
        """
        if observed_modalities is None:
            observed_modalities = list(v_dict.keys())
        
        # Encode to hyperspherical space
        z_dict = self.encode_modalities(v_dict)
        
        # Get prototypes
        prototypes = self.geometric_rectification.get_prototypes()
        if prototypes is None:
            # Initialize with complete samples if available
            # Use average of all modality embeddings for each sample
            if len(observed_modalities) == self.num_modalities:
                # Check if all modalities have the same batch size
                batch_sizes = [z_dict[m].size(0) for m in sorted(observed_modalities) if m in z_dict]
                if len(batch_sizes) == self.num_modalities and len(set(batch_sizes)) == 1:
                    # All modalities have the same batch size
                    batch_size = batch_sizes[0]
                    z_all_list = []
                    for m in sorted(observed_modalities):
                        if m in z_dict:
                            z_all_list.append(z_dict[m])
                    
                    if len(z_all_list) == self.num_modalities:
                        # Average across modalities: [batch_size, latent_dim]
                        z_all = torch.stack(z_all_list, dim=0).mean(dim=0)
                        if z_all.size(0) >= self.num_clusters:
                            self.geometric_rectification.soft_cluster.initialize_prototypes(z_all)
                            prototypes = self.geometric_rectification.get_prototypes()
                        else:
                            # If not enough samples, use random initialization
                            device = z_all.device
                            prototypes = torch.randn(self.num_clusters, self.latent_dim, device=device)
                            prototypes = prototypes / (torch.norm(prototypes, p=2, dim=1, keepdim=True) + 1e-8)
                            self.geometric_rectification.soft_cluster.prototypes = prototypes
                            prototypes = self.geometric_rectification.get_prototypes()
                    else:
                        # Not all modalities available, use random initialization
                        device = list(z_dict.values())[0].device
                        prototypes = torch.randn(self.num_clusters, self.latent_dim, device=device)
                        prototypes = prototypes / (torch.norm(prototypes, p=2, dim=1, keepdim=True) + 1e-8)
                        self.geometric_rectification.soft_cluster.prototypes = prototypes
                        prototypes = self.geometric_rectification.get_prototypes()
                else:
                    # Different batch sizes or missing modalities, use random initialization
                    device = list(z_dict.values())[0].device
                    prototypes = torch.randn(self.num_clusters, self.latent_dim, device=device)
                    prototypes = prototypes / (torch.norm(prototypes, p=2, dim=1, keepdim=True) + 1e-8)
                    self.geometric_rectification.soft_cluster.prototypes = prototypes
                    prototypes = self.geometric_rectification.get_prototypes()
        
        # Determine batch size (use the maximum batch size across all modalities)
        # Get device from model parameters to ensure consistency
        device = next(self.parameters()).device
        batch_sizes = [z_dict[m].size(0) for m in z_dict.keys() if z_dict[m] is not None]
        if len(batch_sizes) > 0:
            max_batch_size = max(batch_sizes)
        else:
            max_batch_size = 0
        
        # Restore missing modalities
        z_final_dict = {}
        for v in range(self.num_modalities):
            v_str = str(v)
            if v_str in observed_modalities and v_str in z_dict:
                # Use observed modality (possibly refined during restoration phase)
                if training_phase in ['restoration', 'all'] and len(observed_modalities) > 1:
                    # Refine observed modality using other observed modalities
                    z_final = self.structural_restoration(
                        z_dict, observed_modalities, v_str, prototypes
                    )
                else:
                    # Use original embedding during topology phase
                    z_final = z_dict[v_str]
            else:
                # Restore missing modality
                if prototypes is not None:
                    z_final = self.structural_restoration(
                        z_dict, observed_modalities, v_str, prototypes
                    )
                else:
                    # Fallback: use zero vector if prototypes not initialized
                    z_final = torch.zeros(max_batch_size, self.latent_dim, device=device)
            
            # Ensure all modalities have the same batch size
            if z_final.size(0) < max_batch_size:
                # Pad with zeros if batch size is smaller
                padding = torch.zeros(max_batch_size - z_final.size(0), self.latent_dim, device=device)
                z_final = torch.cat([z_final, padding], dim=0)
            elif z_final.size(0) > max_batch_size:
                # Truncate if batch size is larger (shouldn't happen, but just in case)
                z_final = z_final[:max_batch_size]
            
            z_final_dict[v_str] = z_final
        
        # Fusion
        h = self.fusion(z_final_dict)
        
        # Classification
        logits = None
        if self.classifier is not None:
            logits = self.classifier(h)
        
        outputs = {
            'z_dict': z_dict,
            'z_final_dict': z_final_dict,
            'h': h,
            'logits': logits,
            'prototypes': prototypes
        }
        
        return outputs
    
    def compute_losses(self, outputs, v_dict, labels=None, progress=0.0, 
                      complete_indices=None, incomplete_indices=None, 
                      skip_align=False, skip_rest=False):
        """
        Compute all losses according to paper equations
        Args:
            outputs: outputs from forward pass
            v_dict: original input features
            labels: ground truth labels (optional)
            progress: training progress [0, 1]
            complete_indices: indices of complete samples in batch
            incomplete_indices: indices of incomplete samples in batch
            skip_align: skip geometric alignment loss (for warm-up)
            skip_rest: skip restoration loss (for warm-up)
        Returns:
            losses: dict of losses
        """
        device = next(self.parameters()).device
        losses = {}
        
        z_dict = outputs['z_dict']
        z_final_dict = outputs['z_final_dict']
        prototypes = outputs['prototypes']
        
        # Topology loss (Equation 4): L_topo = sum_m E[||v^(m) - D_m(z^(m))||_F^2] 
        #                              - lambda_cl * sum_{u!=v} E[log P_{i,i}^{(v|u)}]
        # Should be computed on complete samples only
        if complete_indices is not None and len(complete_indices) > 0:
            # Extract complete samples, filtering out invalid indices
            z_dict_complete = {}
            for m in z_dict.keys():
                if z_dict[m] is not None:
                    valid_indices = [i for i in complete_indices if i < z_dict[m].size(0)]
                    if len(valid_indices) > 0:
                        z_dict_complete[m] = z_dict[m][valid_indices]
            
            v_dict_complete = {}
            for m in v_dict.keys():
                if m in v_dict and v_dict[m] is not None:
                    valid_indices = [i for i in complete_indices if i < v_dict[m].size(0)]
                    if len(valid_indices) > 0:
                        v_dict_complete[m] = v_dict[m][valid_indices]
            
            if len(z_dict_complete) > 0 and len(v_dict_complete) > 0:
                loss_topo, loss_recon, loss_contrast = self.topology_loss_fn(
                    z_dict_complete, v_dict_complete, self.decoders
                )
            else:
                loss_topo = torch.tensor(0.0, device=device)
                loss_recon = torch.tensor(0.0, device=device)
                loss_contrast = torch.tensor(0.0, device=device)
        else:
            # If no complete samples, compute on all samples
            loss_topo, loss_recon, loss_contrast = self.topology_loss_fn(
                z_dict, v_dict, self.decoders
            )
        
        losses['topo'] = loss_topo
        losses['recon'] = loss_recon
        losses['contrast'] = loss_contrast
        
        # Geometric rectification loss (Equation 8): L_align = L_dec + gamma * L_ad
        # Requires both complete and incomplete samples
        loss_align = torch.tensor(0.0, device=device)
        loss_ad = torch.tensor(0.0, device=device)
        loss_dec = torch.tensor(0.0, device=device)
        
        if not skip_align and (complete_indices is not None and incomplete_indices is not None and 
            len(complete_indices) > 0 and len(incomplete_indices) > 0):
            # Find common valid indices across all modalities for complete samples
            all_modalities = sorted(z_dict.keys())
            valid_complete_indices = complete_indices
            for m in all_modalities:
                if z_dict[m] is not None:
                    valid_complete_indices = [i for i in valid_complete_indices if i < z_dict[m].size(0)]
            
            # Find common valid indices across all modalities for incomplete samples
            valid_incomplete_indices = incomplete_indices
            for m in all_modalities:
                if z_dict[m] is not None:
                    valid_incomplete_indices = [i for i in valid_incomplete_indices if i < z_dict[m].size(0)]
            
            if len(valid_complete_indices) > 0 and len(valid_incomplete_indices) > 0:
                # Aggregate embeddings across modalities for complete samples
                z_complete_list = []
                for m in all_modalities:
                    if z_dict[m] is not None:
                        z_complete_m = z_dict[m][valid_complete_indices]  # [N_C, latent_dim]
                        z_complete_list.append(z_complete_m)
                
                # Aggregate embeddings across modalities for incomplete samples
                z_incomplete_list = []
                for m in all_modalities:
                    if z_dict[m] is not None:
                        z_incomplete_m = z_dict[m][valid_incomplete_indices]  # [N_I, latent_dim]
                        z_incomplete_list.append(z_incomplete_m)
                
                if len(z_complete_list) > 0 and len(z_incomplete_list) > 0:
                    # Average across modalities: [N_C, latent_dim] and [N_I, latent_dim]
                    # This represents the aggregated representation for each sample
                    z_complete = torch.stack(z_complete_list, dim=0).mean(dim=0)
                    z_incomplete = torch.stack(z_incomplete_list, dim=0).mean(dim=0)
                    
                    # Ensure embeddings are on the hypersphere (L2 normalized)
                    z_complete = z_complete / (torch.norm(z_complete, p=2, dim=1, keepdim=True) + 1e-8)
                    z_incomplete = z_incomplete / (torch.norm(z_incomplete, p=2, dim=1, keepdim=True) + 1e-8)
                    
                    # Compute geometric rectification loss
                    loss_align, loss_ad, loss_dec = self.geometric_rectification(
                        z_complete, z_incomplete, progress, update_prototypes=True
                    )
        
        losses['align'] = loss_align
        losses['ad'] = loss_ad
        losses['dec'] = loss_dec
        
        # Restoration loss (Equation 9): L_rest = E_x~X_C E_v~M(x) [||z^(v) - z_final^(v)||_2^2]
        # Should be computed on complete samples only (self-supervised)
        if not skip_rest and complete_indices is not None and len(complete_indices) > 0:
            z_dict_complete = {}
            for m in z_dict.keys():
                if z_dict[m] is not None:
                    valid_indices = [i for i in complete_indices if i < z_dict[m].size(0)]
                    if len(valid_indices) > 0:
                        z_dict_complete[m] = z_dict[m][valid_indices]
            
            if len(z_dict_complete) > 0:
                # Clone z_dict to avoid computation graph issues
                z_dict_complete_cloned = {m: z_dict_complete[m].clone() for m in z_dict_complete.keys()}
                loss_rest = self.structural_restoration.compute_restoration_loss(
                    z_dict_complete_cloned, prototypes
                )
            else:
                loss_rest = torch.tensor(0.0, device=device)
        else:
            loss_rest = torch.tensor(0.0, device=device)
        
        losses['rest'] = loss_rest
        
        # Classification loss
        loss_task = torch.tensor(0.0, device=device)
        if labels is not None and outputs['logits'] is not None:
            logits = outputs['logits']
            # Ensure logits and labels have the same batch size
            if logits.size(0) != labels.size(0):
                min_batch_size = min(logits.size(0), labels.size(0))
                logits = logits[:min_batch_size]
                labels = labels[:min_batch_size]
            if logits.size(0) > 0:
                loss_task = nn.CrossEntropyLoss()(logits, labels)
        losses['task'] = loss_task
        
        # Total loss (from paper): L_total = lambda_geo * L_geo + lambda_rest * L_rest + L_task
        # where L_geo = L_topo + L_align
        loss_geo = loss_topo + loss_align
        loss_total = (self.lambda_geo * loss_geo + 
                     self.lambda_rest * loss_rest + 
                     loss_task)
        losses['total'] = loss_total
        
        return losses

