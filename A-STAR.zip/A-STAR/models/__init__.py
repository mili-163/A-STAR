"""
Multi-Modal Learning with Non-IID Missing Modalities
"""
from .encoders import ModalityEncoder, ModalityDecoder, HypersphericalProjection
from .topology import HypersphericalSimilarity, ConditionalDistribution, TopologyConsistencyLoss
from .geometric_rectification import (
    GradientReversalLayer, GradientReversal, DomainDiscriminator,
    SoftClusterEvolution, GeometricRectification
)
from .restoration import (
    ResidualMapper, PrototypeInduction, AdaptiveFusion,
    ModalityRestoration, StructuralRestoration
)
from .fusion import ModalityFusion, Classifier

__all__ = [
    'ModalityEncoder', 'ModalityDecoder', 'HypersphericalProjection',
    'HypersphericalSimilarity', 'ConditionalDistribution', 'TopologyConsistencyLoss',
    'GradientReversalLayer', 'GradientReversal', 'DomainDiscriminator',
    'SoftClusterEvolution', 'GeometricRectification',
    'ResidualMapper', 'PrototypeInduction', 'AdaptiveFusion',
    'ModalityRestoration', 'StructuralRestoration',
    'ModalityFusion', 'Classifier'
]

