"""
Canonical Semantic Topology Construction
- Hyperspherical similarity distribution learning
- Topology-consistency objective
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class HypersphericalSimilarity(nn.Module):
    """
    Compute hyperspherical similarity between modalities
    Equation (2): s_{i,j}^{(u,v)} = z_i^(u)^T * z_j^(v)
    """
    def __init__(self):
        super(HypersphericalSimilarity, self).__init__()
    
    def forward(self, z_u, z_v):
        """
        Args:
            z_u: embeddings from modality u [batch_size, latent_dim]
            z_v: embeddings from modality v [batch_size, latent_dim]
        Returns:
            similarity: [batch_size, batch_size]
        """
        # Dot product = cosine similarity (since embeddings are L2 normalized)
        similarity = torch.matmul(z_u, z_v.t())
        return similarity


class ConditionalDistribution(nn.Module):
    """
    Convert similarities to conditional distribution (InfoNCE-style)
    Equation (3): P_{i,j}^{(v|u)} = exp(s_{i,j}^{(u,v)}/tau) / sum_k exp(s_{i,k}^{(u,v)}/tau)
    """
    def __init__(self, temperature=0.07):
        super(ConditionalDistribution, self).__init__()
        self.temperature = temperature
    
    def forward(self, similarity):
        """
        Args:
            similarity: [batch_size, batch_size]
        Returns:
            prob: conditional distribution [batch_size, batch_size]
        """
        prob = F.softmax(similarity / self.temperature, dim=1)
        return prob


class TopologyConsistencyLoss(nn.Module):
    """
    Topology-consistency objective
    Equation (4): L_topo = sum_m E[||v^(m) - D_m(z^(m))||_F^2] 
                  - lambda_cl * sum_{u!=v} E[log P_{i,i}^{(v|u)}]
    """
    def __init__(self, lambda_cl=0.5, temperature=0.07):
        super(TopologyConsistencyLoss, self).__init__()
        self.lambda_cl = lambda_cl
        self.temperature = temperature
        self.similarity_fn = HypersphericalSimilarity()
        self.dist_fn = ConditionalDistribution(temperature)
    
    def forward(self, z_dict, v_dict, decoders):
        """
        Args:
            z_dict: dict of {modality_id: z_embeddings} [batch_size, latent_dim]
            v_dict: dict of {modality_id: original_features} [batch_size, input_dim]
            decoders: dict of {modality_id: decoder}
        Returns:
            loss: scalar tensor
        """
        batch_size = list(z_dict.values())[0].size(0)
        num_modalities = len(z_dict)
        
        # Reconstruction loss (first term)
        recon_loss = 0.0
        num_modalities_with_data = 0
        for m, z_m in z_dict.items():
            if m in v_dict and v_dict[m] is not None:
                v_m = v_dict[m]
                v_recon = decoders[m](z_m)
                recon_loss += F.mse_loss(v_recon, v_m)
                num_modalities_with_data += 1
        
        # Normalize by number of modalities
        if num_modalities_with_data > 0:
            recon_loss = recon_loss / num_modalities_with_data
        
        # Cross-modal contrastive loss (second term)
        contrastive_loss = 0.0
        modalities = list(z_dict.keys())
        
        for u_idx, u in enumerate(modalities):
            for v_idx, v in enumerate(modalities):
                if u != v:
                    z_u = z_dict[u]
                    z_v = z_dict[v]
                    
                    # Compute similarity matrix
                    similarity = self.similarity_fn(z_u, z_v)  # [B, B]
                    
                    # Compute conditional distribution
                    prob = self.dist_fn(similarity)  # [B, B]
                    
                    # Positive pairs are on the diagonal (i, i)
                    # Negative pairs are off-diagonal (i, j) where i != j
                    # We maximize log P_{i,i}^{(v|u)} for positive pairs
                    pos_prob = torch.diag(prob)  # [B]
                    contrastive_loss -= torch.mean(torch.log(pos_prob + 1e-8))
        
        # Normalize by number of modality pairs
        num_pairs = num_modalities * (num_modalities - 1)
        if num_pairs > 0:
            contrastive_loss = contrastive_loss / num_pairs
        
        total_loss = recon_loss - self.lambda_cl * contrastive_loss
        
        return total_loss, recon_loss, contrastive_loss

