"""
Downstream classification and fusion modules
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class ModalityFusion(nn.Module):
    """
    Learnable fusion operator F_fusion
    Equation (10): h = F_fusion({z_final^(v)}_{v=1}^M)
    """
    def __init__(self, num_modalities, latent_dim, fusion_type='attention'):
        super(ModalityFusion, self).__init__()
        self.num_modalities = num_modalities
        self.latent_dim = latent_dim
        self.fusion_type = fusion_type
        
        if fusion_type == 'attention':
            # Attention-based fusion
            self.query = nn.Linear(latent_dim, latent_dim)
            self.key = nn.Linear(latent_dim, latent_dim)
            self.value = nn.Linear(latent_dim, latent_dim)
            self.output_proj = nn.Linear(latent_dim, latent_dim)
        elif fusion_type == 'weighted_sum':
            # Learnable weighted sum
            self.weights = nn.Parameter(torch.ones(num_modalities) / num_modalities)
            self.proj = nn.Linear(latent_dim, latent_dim)
        elif fusion_type == 'concat':
            # Concatenation + projection
            self.proj = nn.Linear(num_modalities * latent_dim, latent_dim)
        else:
            raise ValueError(f"Unknown fusion type: {fusion_type}")
    
    def forward(self, z_dict):
        """
        Args:
            z_dict: dict of {modality_id: z_final} [batch_size, latent_dim]
        Returns:
            h: fused representation [batch_size, latent_dim]
        """
        modalities = sorted(z_dict.keys())
        
        # Check batch sizes and find the maximum
        batch_sizes = [z_dict[m].size(0) for m in modalities]
        max_batch_size = max(batch_sizes) if batch_sizes else 0
        
        # Ensure all modalities have the same batch size
        z_list = []
        for m in modalities:
            z_m = z_dict[m]
            if z_m.size(0) < max_batch_size:
                # Pad with zeros if batch size is smaller
                device = z_m.device
                padding = torch.zeros(max_batch_size - z_m.size(0), z_m.size(1), device=device)
                z_m = torch.cat([z_m, padding], dim=0)
            z_list.append(z_m)
        
        z_stack = torch.stack(z_list, dim=1)  # [B, M, latent_dim]
        
        if self.fusion_type == 'attention':
            # Self-attention across modalities
            Q = self.query(z_stack)  # [B, M, latent_dim]
            K = self.key(z_stack)  # [B, M, latent_dim]
            V = self.value(z_stack)  # [B, M, latent_dim]
            
            # Attention scores
            scores = torch.matmul(Q, K.transpose(-2, -1)) / (self.latent_dim ** 0.5)
            attn_weights = F.softmax(scores, dim=-1)  # [B, M, M]
            
            # Weighted sum
            z_attn = torch.matmul(attn_weights, V)  # [B, M, latent_dim]
            
            # Aggregate across modalities (mean pooling)
            z_agg = z_attn.mean(dim=1)  # [B, latent_dim]
            h = self.output_proj(z_agg)
            
        elif self.fusion_type == 'weighted_sum':
            # Weighted sum
            weights = F.softmax(self.weights, dim=0)  # [M]
            z_weighted = torch.sum(z_stack * weights.unsqueeze(0).unsqueeze(-1), dim=1)  # [B, latent_dim]
            h = self.proj(z_weighted)
            
        elif self.fusion_type == 'concat':
            # Concatenate and project
            z_concat = z_stack.view(-1, self.num_modalities * self.latent_dim)  # [B, M*latent_dim]
            h = self.proj(z_concat)
        
        return h


class Classifier(nn.Module):
    """
    Downstream classifier
    """
    def __init__(self, latent_dim, num_classes, hidden_dims=None):
        super(Classifier, self).__init__()
        if hidden_dims is None:
            hidden_dims = [128, 64]
        
        layers = []
        prev_dim = latent_dim
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(0.2))
            prev_dim = hidden_dim
        
        layers.append(nn.Linear(prev_dim, num_classes))
        self.classifier = nn.Sequential(*layers)
    
    def forward(self, h):
        """
        Args:
            h: fused representation [batch_size, latent_dim]
        Returns:
            logits: classification logits [batch_size, num_classes]
        """
        return self.classifier(h)

