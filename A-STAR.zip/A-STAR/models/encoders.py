"""
Modality-specific encoders and decoders
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class ModalityEncoder(nn.Module):
    """Modality-specific encoder E_m"""
    def __init__(self, input_dim, latent_dim, hidden_dims=None):
        super(ModalityEncoder, self).__init__()
        if hidden_dims is None:
            hidden_dims = [512, 256]
        
        layers = []
        prev_dim = input_dim
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(0.1))
            prev_dim = hidden_dim
        
        layers.append(nn.Linear(prev_dim, latent_dim))
        self.encoder = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.encoder(x)


class ModalityDecoder(nn.Module):
    """Modality-specific decoder D_m for reconstruction"""
    def __init__(self, latent_dim, output_dim, hidden_dims=None):
        super(ModalityDecoder, self).__init__()
        if hidden_dims is None:
            hidden_dims = [256, 512]
        
        layers = []
        prev_dim = latent_dim
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(0.1))
            prev_dim = hidden_dim
        
        layers.append(nn.Linear(prev_dim, output_dim))
        self.decoder = nn.Sequential(*layers)
    
    def forward(self, z):
        return self.decoder(z)


class HypersphericalProjection(nn.Module):
    """
    Hyperspherical embedding with L2 normalization
    Equation (1): z_i^(m) = E_m(v_i^(m)) / (||E_m(v_i^(m))||_2 + epsilon)
    """
    def __init__(self, encoder, epsilon=1e-8):
        super(HypersphericalProjection, self).__init__()
        self.encoder = encoder
        self.epsilon = epsilon
    
    def forward(self, v):
        """
        Args:
            v: input feature vector [batch_size, input_dim]
        Returns:
            z: normalized embedding on unit hypersphere [batch_size, latent_dim]
        """
        z_raw = self.encoder(v)
        z_norm = torch.norm(z_raw, p=2, dim=1, keepdim=True)
        z = z_raw / (z_norm + self.epsilon)
        return z

