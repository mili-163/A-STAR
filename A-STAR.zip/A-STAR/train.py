"""
Main training script
"""
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import yaml
import os
from tqdm import tqdm
import numpy as np
try:
    from torch.utils.tensorboard import SummaryWriter
except ImportError:
    try:
        from tensorboard import SummaryWriter
    except ImportError:
        print("Warning: tensorboard not available, using dummy writer")
        class SummaryWriter:
            def __init__(self, *args, **kwargs):
                pass
            def add_scalar(self, *args, **kwargs):
                pass
            def close(self):
                pass

from models.main_model import MultiModalModel
from data.dataset import MultiModalDataset, collate_fn, create_synthetic_data


def load_config(config_path):
    """Load configuration from YAML file"""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    return config


def create_data_loaders(config, train_data_dict, train_labels, 
                       val_data_dict, val_labels):
    """Create data loaders for training and validation"""
    train_dataset = MultiModalDataset(
        train_data_dict, train_labels,
        missing_rate=config['data']['missing_rate'],
        non_iid=config['data']['non_iid']
    )
    
    val_dataset = MultiModalDataset(
        val_data_dict, val_labels,
        missing_rate=0.0,  # No missing in validation for evaluation
        non_iid=False
    )
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=config['training']['batch_size'],
        shuffle=True,
        collate_fn=collate_fn,
        num_workers=0
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=config['training']['batch_size'],
        shuffle=False,
        collate_fn=collate_fn,
        num_workers=0
    )
    
    return train_loader, val_loader, train_dataset


def separate_complete_incomplete(batch_dict, model):
    """
    Separate batch into complete and incomplete samples
    """
    batch_size = len(batch_dict['observed'])
    complete_indices = []
    incomplete_indices = []
    
    num_modalities = model.num_modalities
    
    for i in range(batch_size):
        observed = batch_dict['observed'][i]
        if len(observed) == num_modalities:
            complete_indices.append(i)
        else:
            incomplete_indices.append(i)
    
    return complete_indices, incomplete_indices


def process_batch(batch_dict, model, device):
    """
    Process batch and prepare inputs for model
    """
    # Move to device
    v_dict = {}
    for m, features in batch_dict['features'].items():
        if features is not None:
            v_dict[m] = features.to(device)
    
    labels = None
    if batch_dict['labels'] is not None:
        labels = batch_dict['labels'].to(device)
    
    # Get observed modalities for each sample
    # For simplicity, we'll use the union of all observed modalities in the batch
    observed_modalities = set()
    for obs_list in batch_dict['observed']:
        observed_modalities.update(obs_list)
    observed_modalities = sorted(list(observed_modalities))
    
    return v_dict, labels, observed_modalities


def train_epoch(model, train_loader, optimizer, scheduler, device, epoch, config, writer):
    """Train for one epoch"""
    model.train()
    total_loss = 0.0
    loss_dict = {
        'topo': 0.0, 'recon': 0.0, 'contrast': 0.0,
        'align': 0.0, 'ad': 0.0, 'dec': 0.0,
        'rest': 0.0, 'task': 0.0
    }
    
    num_batches = len(train_loader)
    progress = epoch / config['training']['num_epochs']
    warmup_epochs = config['training'].get('warmup_epochs', 5)
    is_warmup = epoch < warmup_epochs
    
    pbar = tqdm(train_loader, desc=f'Epoch {epoch+1} {"[Warm-up]" if is_warmup else ""}')
    
    for batch_idx, batch_dict in enumerate(pbar):
        # Process batch
        v_dict, labels, observed_modalities = process_batch(
            batch_dict, model, device
        )
        
        if len(v_dict) == 0:
            continue
        
        # Forward pass
        # During warm-up, only use topology phase
        training_phase = 'topology' if is_warmup else 'all'
        outputs = model(v_dict, observed_modalities, training_phase=training_phase)
        
        # Separate complete and incomplete for geometric rectification
        complete_indices, incomplete_indices = separate_complete_incomplete(
            batch_dict, model
        )
        
        # Convert to lists for indexing (ensure they are valid)
        complete_indices = complete_indices if len(complete_indices) > 0 else None
        incomplete_indices = incomplete_indices if len(incomplete_indices) > 0 else None
        
        # Ensure we have valid indices for loss computation
        if complete_indices is not None:
            # Filter out invalid indices
            batch_size = len(batch_dict['observed'])
            complete_indices = [i for i in complete_indices if i < batch_size]
            complete_indices = complete_indices if len(complete_indices) > 0 else None
        
        if incomplete_indices is not None:
            batch_size = len(batch_dict['observed'])
            incomplete_indices = [i for i in incomplete_indices if i < batch_size]
            incomplete_indices = incomplete_indices if len(incomplete_indices) > 0 else None
        
        # Compute losses
        # During warm-up: skip alignment and restoration losses to avoid computation graph issues
        losses = model.compute_losses(
            outputs, v_dict, labels, progress,
            complete_indices=complete_indices,
            incomplete_indices=incomplete_indices,
            skip_align=is_warmup,
            skip_rest=is_warmup
        )
        
        # During warm-up: only use topology loss
        if is_warmup:
            losses['total'] = losses['topo']
        
        # Backward pass
        optimizer.zero_grad()
        # Use retain_graph=False by default, but set to True if needed for complex loss computations
        losses['total'].backward(retain_graph=False)
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        
        # Update learning rate scheduler (step per batch for cosine annealing)
        if scheduler is not None:
            scheduler.step()
        
        # Accumulate losses
        total_loss += losses['total'].item()
        for key in loss_dict:
            if key in losses:
                loss_dict[key] += losses[key].item()
        
        # Update progress bar
        current_lr = optimizer.param_groups[0]['lr']
        pbar.set_postfix({
            'loss': losses['total'].item(),
            'topo': losses.get('topo', 0).item(),
            'align': losses.get('align', 0).item(),
            'rest': losses.get('rest', 0).item(),
            'lr': f'{current_lr:.2e}'
        })
    
    # Average losses
    total_loss /= num_batches
    for key in loss_dict:
        loss_dict[key] /= num_batches
    
    # Log to tensorboard
    if writer is not None:
        writer.add_scalar('Train/TotalLoss', total_loss, epoch)
        writer.add_scalar('Train/LearningRate', optimizer.param_groups[0]['lr'], epoch)
        for key, value in loss_dict.items():
            writer.add_scalar(f'Train/{key}', value, epoch)
    
    return total_loss, loss_dict


def validate(model, val_loader, device, epoch, writer):
    """Validate model"""
    model.eval()
    total_loss = 0.0
    correct = 0
    total = 0
    
    with torch.no_grad():
        for batch_dict in tqdm(val_loader, desc='Validation'):
            v_dict, labels, observed_modalities = process_batch(
                batch_dict, model, device
            )
            
            if len(v_dict) == 0:
                continue
            
            # Forward pass
            outputs = model(v_dict, observed_modalities, training_phase='all')
            
            # Separate complete and incomplete for loss computation
            complete_indices, incomplete_indices = separate_complete_incomplete(
                batch_dict, model
            )
            complete_indices = complete_indices if len(complete_indices) > 0 else None
            incomplete_indices = incomplete_indices if len(incomplete_indices) > 0 else None
            
            # Compute losses (no skipping during validation)
            losses = model.compute_losses(
                outputs, v_dict, labels, progress=1.0,
                complete_indices=complete_indices,
                incomplete_indices=incomplete_indices,
                skip_align=False,
                skip_rest=False
            )
            total_loss += losses['total'].item()
            
            # Compute accuracy
            if outputs['logits'] is not None and labels is not None:
                _, predicted = torch.max(outputs['logits'], 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
    
    avg_loss = total_loss / len(val_loader)
    accuracy = 100 * correct / total if total > 0 else 0.0
    
    # Log to tensorboard
    if writer is not None:
        writer.add_scalar('Val/Loss', avg_loss, epoch)
        writer.add_scalar('Val/Accuracy', accuracy, epoch)
    
    return avg_loss, accuracy


def main():
    # Load config
    config_path = 'config.yaml'
    if not os.path.exists(config_path):
        print(f"Config file {config_path} not found. Using default config.")
        config = {
            'model': {
                'num_modalities': 3,
                'input_dims': [768, 35, 74],  # Text (BERT), Visual (FACET), Acoustic (COVAREP)
                'latent_dim': 512,
                'num_clusters': 20,
                'temperature': 0.1,
                'alpha': 1.0,
                'ema_momentum': 0.99,
                'prototype_update_freq': 5
            },
            'training': {
                'batch_size': 64,
                'num_epochs': 100,
                'learning_rate': 0.001,
                'min_learning_rate': 0.000001,
                'weight_decay': 0.0001,
                'warmup_epochs': 5,
                'beta1': 0.9,
                'beta2': 0.999,
                'lr_scheduler': 'cosine'
            },
            'loss': {
                'lambda_cl': 0.3,
                'lambda_grl': 1.0,
                'gamma_sch': 10.0,
                'gamma': 0.1,
                'lambda_geo': 0.4,
                'lambda_rest': 1.0
            },
            'data': {
                'missing_rate': 0.3,
                'non_iid': True,
                'dataset': 'CMU-MOSEI'
            }
        }
    else:
        config = load_config(config_path)
    
    # Set device - prefer GPU if available
    if torch.cuda.is_available():
        device = torch.device('cuda')
        print(f'Using GPU: {torch.cuda.get_device_name(0)}')
        print(f'CUDA version: {torch.version.cuda}')
        print(f'GPU memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.2f} GB')
    else:
        device = torch.device('cpu')
        print('Using CPU (GPU not available)')
    
    # Create synthetic data (replace with your data loading)
    print('Creating synthetic data...')
    train_data_dict, train_labels = create_synthetic_data(
        num_samples=2000,
        num_modalities=config['model']['num_modalities'],
        input_dims=config['model']['input_dims'],
        num_classes=10
    )
    
    val_data_dict, val_labels = create_synthetic_data(
        num_samples=500,
        num_modalities=config['model']['num_modalities'],
        input_dims=config['model']['input_dims'],
        num_classes=10,
        seed=123
    )
    
    # Adjust batch size based on dataset
    dataset_name = config['data'].get('dataset', 'CMU-MOSEI')
    if dataset_name == 'CMU-MOSI':
        config['training']['batch_size'] = 32
    else:  # CMU-MOSEI
        config['training']['batch_size'] = 64
    print(f'Using batch size: {config["training"]["batch_size"]} for {dataset_name}')
    
    # Create data loaders
    train_loader, val_loader, train_dataset = create_data_loaders(
        config, train_data_dict, train_labels, val_data_dict, val_labels
    )
    
    # Create model
    print('Creating model...')
    model = MultiModalModel(config).to(device)
    model.set_num_classes(10)  # Set number of classes
    
    # Create optimizer with Adam parameters from paper
    optimizer = optim.Adam(
        model.parameters(),
        lr=config['training']['learning_rate'],
        betas=(
            config['training'].get('beta1', 0.9),
            config['training'].get('beta2', 0.999)
        ),
        weight_decay=config['training']['weight_decay']
    )
    
    # Create learning rate scheduler (cosine annealing)
    num_epochs = config['training']['num_epochs']
    num_training_steps = len(train_loader) * num_epochs
    min_lr = config['training'].get('min_learning_rate', 1e-6)
    
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=num_training_steps,  # Total number of training steps
        eta_min=min_lr
    )
    
    # Create tensorboard writer
    writer = SummaryWriter('runs/experiment')
    
    # Training loop
    print('Starting training...')
    print(f'Warm-up epochs: {config["training"].get("warmup_epochs", 5)}')
    print(f'Total epochs: {num_epochs}')
    best_val_acc = 0.0
    
    for epoch in range(num_epochs):
        # Train
        train_loss, train_loss_dict = train_epoch(
            model, train_loader, optimizer, scheduler, device, epoch, config, writer
        )
        
        # Validate
        val_loss, val_acc = validate(model, val_loader, device, epoch, writer)
        
        print(f'Epoch {epoch+1}/{config["training"]["num_epochs"]}: '
              f'Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}, '
              f'Val Acc: {val_acc:.2f}%')
        
        # Save best model
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_acc': val_acc,
                'config': config
            }, 'best_model.pth')
            print(f'New best model saved with accuracy: {val_acc:.2f}%')
    
    writer.close()
    print('Training completed!')


if __name__ == '__main__':
    main()

