"""
Data loading and preprocessing for multi-modal learning
"""
import torch
from torch.utils.data import Dataset
import numpy as np
from typing import Dict, List, Optional


class MultiModalDataset(Dataset):
    """
    Multi-modal dataset with support for missing modalities
    """
    def __init__(self, data_dict, labels=None, missing_rate=0.0, non_iid=False, 
                 missing_pattern=None):
        """
        Args:
            data_dict: dict of {modality_id: features} where each is [N, d_m]
            labels: optional labels [N]
            missing_rate: probability of missing a modality (for random missingness)
            non_iid: whether to use non-IID missingness patterns
            missing_pattern: optional pre-defined missing pattern [N, M] binary matrix
        """
        self.num_samples = len(list(data_dict.values())[0])
        self.modalities = sorted(data_dict.keys())
        self.num_modalities = len(self.modalities)
        
        # Store data (will be moved to device during training)
        self.data_dict = {str(m): torch.FloatTensor(data_dict[m]) 
                         for m in self.modalities}
        self.labels = torch.LongTensor(labels) if labels is not None else None
        
        # Generate missing patterns
        if missing_pattern is not None:
            self.missing_pattern = torch.BoolTensor(missing_pattern)
        else:
            self.missing_pattern = self._generate_missing_pattern(
                missing_rate, non_iid
            )
    
    def _generate_missing_pattern(self, missing_rate, non_iid):
        """
        Generate missing pattern matrix
        Returns:
            missing_pattern: [N, M] binary matrix, True means observed
        """
        N = self.num_samples
        M = self.num_modalities
        
        if non_iid:
            # Non-IID: create correlated missing patterns
            # Example: samples with certain characteristics are more likely to miss certain modalities
            pattern = torch.ones(N, M, dtype=torch.bool)
            
            # Create clusters of samples with similar missing patterns
            num_clusters = 3
            cluster_size = N // num_clusters
            
            for cluster_id in range(num_clusters):
                start_idx = cluster_id * cluster_size
                end_idx = start_idx + cluster_size if cluster_id < num_clusters - 1 else N
                
                # Each cluster has a preferred missing modality
                missing_modality = cluster_id % M
                
                # Randomly mask the preferred modality for this cluster
                mask_prob = np.random.uniform(0.3, 0.7)
                mask_indices = np.random.choice(
                    end_idx - start_idx,
                    size=int((end_idx - start_idx) * mask_prob),
                    replace=False
                )
                pattern[start_idx + mask_indices, missing_modality] = False
        else:
            # IID: random missingness
            pattern = torch.rand(N, M) > missing_rate
            # Ensure at least one modality is observed
            pattern[pattern.sum(dim=1) == 0, :] = True
        
        return pattern
    
    def __len__(self):
        return self.num_samples
    
    def __getitem__(self, idx):
        """
        Returns:
            sample: dict with 'features' (dict of modalities), 'observed', 'label'
        """
        sample = {
            'features': {},
            'observed': [],
            'label': None
        }
        
        # Get features for observed modalities
        for i, m in enumerate(self.modalities):
            if self.missing_pattern[idx, i]:
                sample['features'][m] = self.data_dict[m][idx]
                sample['observed'].append(m)
        
        # Get label if available
        if self.labels is not None:
            sample['label'] = self.labels[idx]
        
        return sample
    
    def get_complete_samples(self):
        """Get indices of complete samples (all modalities observed)"""
        complete_mask = self.missing_pattern.sum(dim=1) == self.num_modalities
        return torch.where(complete_mask)[0]
    
    def get_incomplete_samples(self):
        """Get indices of incomplete samples (at least one modality missing)"""
        incomplete_mask = self.missing_pattern.sum(dim=1) < self.num_modalities
        return torch.where(incomplete_mask)[0]


def collate_fn(batch):
    """
    Custom collate function for multi-modal batches
    """
    batch_size = len(batch)
    
    # Collect all unique modalities in the batch
    all_modalities = set()
    for sample in batch:
        all_modalities.update(sample['features'].keys())
    all_modalities = sorted(all_modalities)
    
    # Initialize batch dict
    batch_dict = {
        'features': {m: [] for m in all_modalities},
        'observed': [],
        'labels': []
    }
    
    # Fill batch
    for sample in batch:
        for m in all_modalities:
            if m in sample['features']:
                batch_dict['features'][m].append(sample['features'][m])
            else:
                # Missing modality: use zero vector (will be restored later)
                # We need to know the dimension, so we'll handle this differently
                pass
        batch_dict['observed'].append(sample['observed'])
        if sample['label'] is not None:
            batch_dict['labels'].append(sample['label'])
    
    # Stack features
    for m in all_modalities:
        if len(batch_dict['features'][m]) > 0:
            batch_dict['features'][m] = torch.stack(batch_dict['features'][m])
        else:
            # All samples missing this modality
            batch_dict['features'][m] = None
    
    # Stack labels
    if len(batch_dict['labels']) > 0:
        batch_dict['labels'] = torch.stack(batch_dict['labels'])
    else:
        batch_dict['labels'] = None
    
    return batch_dict


def create_synthetic_data(num_samples=1000, num_modalities=3, input_dims=[2048, 1024, 512],
                          num_classes=10, seed=42):
    """
    Create synthetic multi-modal data for testing
    """
    np.random.seed(seed)
    torch.manual_seed(seed)
    
    data_dict = {}
    labels = np.random.randint(0, num_classes, num_samples)
    
    for m, dim in enumerate(input_dims):
        # Generate features correlated with labels
        features = np.random.randn(num_samples, dim)
        # Add class-specific signal
        for c in range(num_classes):
            mask = labels == c
            features[mask] += np.random.randn(dim) * 0.5
        data_dict[str(m)] = features
    
    return data_dict, labels

